# CareFlow AI - Production Deployment Package

Complete deployment package for CareFlow AI on your custom domain.

## 📦 What's Included

- ✅ Complete Docker setup (backend + frontend)
- ✅ Nginx configuration for reverse proxy
- ✅ SSL/TLS configuration (Cloudflare & Let's Encrypt)
- ✅ Environment variable templates
- ✅ Database migration scripts
- ✅ Deployment scripts
- ✅ Health check scripts

## 🚀 Quick Start

### Option 1: Automated Deploy Script
```bash
./deploy.sh
```

### Option 2: Manual Deploy
See detailed instructions below.

---

## 📋 Deployment Checklist

Use this checklist to track deployment progress:

- [ ] Prerequisites installed (Docker, Docker Compose)
- [ ] Environment variables configured (.env.production)
- [ ] DNS records configured (A and CNAME for careflowAI subdomain)
- [ ] SSL certificate installed
- [ ] Nginx reverse proxy configured
- [ ] Database migrations run
- [ ] Application containers started
- [ ] Health checks passing
- [ ] Frontend accessible at domain
- [ ] Backend API accessible at domain
- [ ] API documentation accessible

---

## 📖 Configuration Files

### 1. Environment Variables

Copy `.env.production.template` to `.env.production` and fill in your values:

```bash
# Required variables
DOMAIN=careflowAI.yourdomain.com
APP_URL=https://careflowAI.yourdomain.com
API_URL=https://api.careflowAI.yourdomain.com
```

### 2. Docker Compose Override

Create `docker-compose.override.yml` for production:

```yaml
version: '3.8'

services:
  backend:
    environment:
      - APP_ENV=production
      - APP_URL=${APP_URL}
      - API_URL=${API_URL}
    ports:
      - "127.0.0.1:8000:8000"  # Only expose locally

  frontend:
    environment:
      - NEXT_PUBLIC_APP_URL=${APP_URL}
      - NEXT_PUBLIC_API_URL=${API_URL}
    ports:
      - "127.0.0.1:3001:3000"  # Only expose locally
```

### 3. Nginx Configuration

See `nginx/careflow-ai.conf` for complete reverse proxy setup.

---

## 🔧 Manual Deployment Instructions

### Step 1: Prepare Your Server

```bash
# SSH into your VPS
ssh root@your-vps-ip

# Install Docker if not already installed
curl -fsSL https://get.docker.com | sh
```

### Step 2: Upload Application Files

```bash
# Upload the deployment package
scp -r careflow-ai-deploy/ root@your-vps-ip:/opt/

# Or extract
cd /opt
unzip careflow-ai-deploy.zip
cd careflow-ai-deploy
```

### Step 3: Configure Environment

```bash
cd /opt/careflow-ai-deploy

# Copy environment template
cp .env.production.template .env.production

# Edit with your values
nano .env.production

# IMPORTANT: Update these values:
# - DOMAIN=careflowAI.yourdomain.com
# - APP_URL=https://careflowAI.yourdomain.com
# - Add your OPENAI_API_KEY
```

### Step 4: Start Services

```bash
cd /opt/careflow-ai-deploy

# Build and start
docker-compose -f docker-compose.prod.yml --build up -d

# Run database migrations
docker-compose -f docker-compose.prod.yml exec backend alembic upgrade head

# Check status
docker-compose -f docker-compose.prod.yml ps
```

### Step 5: Configure Nginx

```bash
# Copy nginx config
sudo cp nginx/careflow-ai.conf /etc/nginx/sites-available/

# Enable site
sudo ln -s /etc/nginx/sites-available/careflow-ai.conf /etc/nginx/sites-enabled/

# Test configuration
sudo nginx -t

# Reload nginx
sudo systemctl reload nginx
```

### Step 6: Configure SSL (Free Options)

#### Let's Encrypt:
```bash
sudo apt-get install -y certbot python3-certbot-nginx
sudo certbot --nginx -d careflowAI.yourdomain.com
```

#### Cloudflare (Recommended):
1. Add your domain to Cloudflare
2. Set SSL/TLS to **Full** mode
3. Enable **Automatic HTTPS Rewrites**

---

## 🔍 Health Check

After deployment, verify all services:

```bash
# Check backend health
curl https://api.careflowAI.yourdomain.com/health

# Check frontend
curl -I https://careflowAI.yourdomain.com

# Expected responses:
# Backend: {"status":"healthy","version":"1.0.0"}
# Frontend: 200 OK with HTML
```

---

## 📚 Service URLs After Deployment

| Service | URL |
|----------|-----|
| Frontend | https://careflowAI.yourdomain.com |
| Backend API | https://api.careflowAI.yourdomain.com |
| API Docs | https://api.careflowAI.yourdomain.com/docs |
| Health | https://api.careflowAI.yourdomain.com/health |

---

## 🛠️ Troubleshooting

### Backend not starting?

```bash
# Check logs
docker-compose -f docker-compose.prod.yml logs backend

# Common issues:
# - Database not ready: Wait for postgres/redis
# - Port conflicts: Ensure ports 8000/3001 are free
# - Environment errors: Check .env.production file
```

### Frontend not accessible?

```bash
# Check nginx is running
sudo systemctl status nginx

# Check nginx logs
sudo tail -f /var/log/nginx/error.log

# Common issues:
# - 502 Bad Gateway: Backend not running
# - SSL errors: Check certificate validity
```

### Database connection errors?

```bash
# Check database is running
docker-compose -f docker-compose.prod.yml exec backend pg_isready

# Test connection
docker-compose -f docker-compose.prod.yml exec backend python -c "from app.core.database import check_async_db_connection; import asyncio; print(asyncio.run(check_async_db_connection()))"
```

---

## 📞 Support

If you encounter issues:

1. Check logs: `docker-compose logs`
2. Check health endpoints above
3. Verify DNS propagation: `nslookup careflowAI.yourdomain.com`
4. Check SSL certificate: `openssl s_client -connect careflowAI.yourdomain.com:443`

---

## 🎉 Next Steps

After successful deployment:

1. **Create admin user** via API or frontend
2. **Configure OpenAI API key** in environment
3. **Set up email/SMS** for notifications (optional)
4. **Enable monitoring** (Sentry, etc.) if needed
5. **Configure backups** for database

---

**Built with ❤️ for easy deployment**
